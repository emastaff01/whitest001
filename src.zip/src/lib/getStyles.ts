// =============================================================
// src/lib/getStyles.ts
// -------------------------------------------------------------
// ウェディングスタイル一覧を取得する関数。
// getPlans.ts と同じ設計：取得ルール（公開中のみ・sortOrder順）を
// この1か所に集約し、画面側は getStyles() を呼ぶだけにする。
// =============================================================

import stylesData from '../data/styles.json';
import type { Style } from '../types';

// 一覧取得：公開中のみ、sortOrder順
export function getStyles(): Style[] {
  const styles = stylesData as Style[];
  return styles
    .filter((style) => style.isPublished) // 下書き（isPublished:false）は出さない
    .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0)); // 小さいほど上
}

// 1件取得：詳細ページ /style/[id] 用
export function getStyleById(id: string): Style | undefined {
  return getStyles().find((style) => style.id === id);
}

// 将来：Firestore版（中身だけ差し替え。呼び出し側は変更不要）
// import { collection, getDocs, query, where, orderBy } from 'firebase/firestore';
// import { db } from './firebase';
// export async function getStyles(): Promise<Style[]> {
//   const q = query(
//     collection(db, 'styles'),
//     where('isPublished', '==', true),
//     orderBy('sortOrder', 'asc')
//   );
//   const snapshot = await getDocs(q);
//   return snapshot.docs.map((doc) => doc.data() as Style);
// }
