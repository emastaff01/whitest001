// =============================================================
// src/lib/getPosts.ts
// -------------------------------------------------------------
// お知らせ（NEWS / Post）一覧を取得する関数。
// ・公開中のみ
// ・publishedAt の降順（新しい順）に並べる
// =============================================================

import postsData from '../data/posts.json';
import type { Post } from '../types';

// 一覧取得：公開中のみ、publishedAt 降順
export function getPosts(): Post[] {
  const posts = postsData as Post[];
  return posts
    .filter((post) => post.isPublished)
    .sort((a, b) => (a.publishedAt < b.publishedAt ? 1 : -1));
}

// 1件取得：詳細ページ /news/[id] 用
export function getPostById(id: string): Post | undefined {
  return getPosts().find((post) => post.id === id);
}

// 将来：Firestore版（中身だけ差し替え）
// import { collection, getDocs, query, where, orderBy } from 'firebase/firestore';
// import { db } from './firebase';
// export async function getPosts(): Promise<Post[]> {
//   const q = query(
//     collection(db, 'posts'),
//     where('isPublished', '==', true),
//     orderBy('publishedAt', 'desc')
//   );
//   const snapshot = await getDocs(q);
//   return snapshot.docs.map((doc) => doc.data() as Post);
// }
