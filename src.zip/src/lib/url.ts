// =============================================================
// src/lib/url.ts
// -------------------------------------------------------------
// サイト内リンクを作るための小さなヘルパー関数です。
//
// 【なぜ必要か】
// このサイトは /test-whi/ というサブディレクトリで動きます。
// そのため、リンクを書くたびに手動で /test-whi/ を付けるのは
// 面倒でミスのもと（付け忘れ＝リンク切れ）になります。
// この url() を通せば、自動で先頭に base（/test-whi）が付き、
// 末尾のスラッシュも整います。本番URLでもリンク切れしません。
//
// 使い方の例:
//   url('/concept')        → '/test-whi/concept/'
//   url('/style/private')  → '/test-whi/style/private/'
//   url('/')               → '/test-whi/'
//
// 注意:
//   外部サイト（https://...）や tel: / mailto: には使いません。
//   それらは href にそのまま書きます。
// =============================================================

export function url(path: string = '/'): string {
  // import.meta.env.BASE_URL には astro.config.mjs の base（'/test-whi/'）が入る
  const base = import.meta.env.BASE_URL.replace(/\/$/, ''); // 末尾スラッシュを除去 → '/test-whi'

  if (path === '/' || path === '') {
    return `${base}/`;
  }

  // 前後のスラッシュを一旦消してから、末尾に / を付けて整える
  // （Astroのディレクトリ形式に合わせ、無駄なリダイレクトを防ぐ）
  const clean = path.replace(/^\/+|\/+$/g, '');
  return `${base}/${clean}/`;
}
